let cards;
let cardNum = 0;
let playerCards;
let dealerCards;
let over1000Flag = 0;
let waitFlag = 0;

function yakuHante() {
	document.getElementById("resDisp").textContent = "";

// カードをランダムに配置

// ボタンを表示
	document.getElementById("reset").style.display ="block";
	document.getElementById("result").style.display ="block";

// ボタンを非表示
	document.getElementById("yakuHante").style.display ="none";

}

function getCard( suit ) {
	let suit_d = [];
	let suit_h = [];
	let suit_c = [];
	let suit_s = [];

	for( let i = 0; i < 14; i++){
		suit_d[i] = 0;
		suit_h[i] = 0;
		suit_c[i] = 0;
		suit_s[i] = 0;
	}

	let board1_suit = document.getElementById("board1_suit").value;
	let board1_num = document.getElementById("board1_num").value;
	if( board1_num == "A" ){
		board1_num = 1;
	}else if( board1_num == "J" ){
		board1_num = 11;
	}else if( board1_num == "Q" ){
		board1_num = 12;
	}else if( board1_num == "K" ){
		board1_num = 13;
	}
	if( board1_suit == "ダイヤ" ){
		suit_d[board1_num]++;
	}else if( board1_suit == "ハート" ){
		suit_h[board1_num]++;
	}else if( board1_suit == "クラブ" ){
		suit_c[board1_num]++;
	}else if( board1_suit == "スペード" ){
		suit_s[board1_num]++;
	}
// console.log("1枚目終わり")

	let board2_suit = document.getElementById("board2_suit").value;
	let board2_num = document.getElementById("board2_num").value;
	if( board2_num == "A" ){
		board2_num = 1;
	}else if( board2_num == "J" ){
		board2_num = 11;
	}else if( board2_num == "Q" ){
		board2_num = 12;
	}else if( board2_num == "K" ){
		board2_num = 13;
	}
	if( board2_suit == "ダイヤ" ){
		suit_d[board2_num]++;
	}else if( board2_suit == "ハート" ){
		suit_h[board2_num]++;
	}else if( board2_suit == "クラブ" ){
		suit_c[board2_num]++;
	}else if( board2_suit == "スペード" ){
		suit_s[board2_num]++;
	}
// 	console.log("2枚目終わり")

	let board3_suit = document.getElementById("board3_suit").value;
	let board3_num = document.getElementById("board3_num").value;
	if( board3_num == "A" ){
		board3_num = 1;
	}else if( board3_num == "J" ){
		board3_num = 11;
	}else if( board3_num == "Q" ){
		board3_num = 12;
	}else if( board3_num == "K" ){
		board3_num = 13;
	}
	if( board3_suit == "ダイヤ" ){
		suit_d[board3_num]++;
	}else if( board3_suit == "ハート" ){
		suit_h[board3_num]++;
	}else if( board3_suit == "クラブ" ){
		suit_c[board3_num]++;
	}else if( board3_suit == "スペード" ){
		suit_s[board3_num]++;
	}

	let board4_suit = document.getElementById("board4_suit").value;
	let board4_num = document.getElementById("board4_num").value;
	if( board4_num == "A" ){
		board4_num = 1;
	}else if( board4_num == "J" ){
		board4_num = 11;
	}else if( board4_num == "Q" ){
		board4_num = 12;
	}else if( board4_num == "K" ){
		board4_num = 13;
	}
	if( board4_suit == "ダイヤ" ){
		suit_d[board4_num]++;
	}else if( board4_suit == "ハート" ){
		suit_h[board4_num]++;
	}else if( board4_suit == "クラブ" ){
		suit_c[board4_num]++;
	}else if( board4_suit == "スペード" ){
		suit_s[board4_num]++;
	}


	let board5_suit = document.getElementById("board5_suit").value;
	let board5_num = document.getElementById("board5_num").value;
	if( board5_num == "A" ){
		board5_num = 1;
	}else if( board5_num == "J" ){
		board5_num = 11;
	}else if( board5_num == "Q" ){
		board5_num = 12;
	}else if( board5_num == "K" ){
		board5_num = 13;
	}
	if( board5_suit == "ダイヤ" ){
		suit_d[board5_num]++;
	}else if( board5_suit == "ハート" ){
		suit_h[board5_num]++;
	}else if( board5_suit == "クラブ" ){
		suit_c[board5_num]++;
	}else if( board5_suit == "スペード" ){
		suit_s[board5_num]++;
	}

	let hand1_suit = document.getElementById("hand1_suit").value;
	let hand1_num = document.getElementById("hand1_num").value;
	if( hand1_num == "A" ){
		hand1_num = 1;
	}else if( hand1_num == "J" ){
		hand1_num = 11;
	}else if( hand1_num == "Q" ){
		hand1_num = 12;
	}else if( hand1_num == "K" ){
		hand1_num = 13;
	}
	if( hand1_suit == "ダイヤ" ){
		suit_d[hand1_num]++;
	}else if( hand1_suit == "ハート" ){
		suit_h[hand1_num]++;
	}else if( hand1_suit == "クラブ" ){
		suit_c[hand1_num]++;
	}else if( hand1_suit == "スペード" ){
		suit_s[hand1_num]++;
	}


	let hand2_suit = document.getElementById("hand2_suit").value;
	let hand2_num = document.getElementById("hand2_num").value;
	if( hand2_num == "A" ){
		hand2_num = 1;
	}else if( hand2_num == "J" ){
		hand2_num = 11;
	}else if( hand2_num == "Q" ){
		hand2_num = 12;
	}else if( hand2_num == "K" ){
		hand2_num = 13;
	}
	if( hand2_suit == "ダイヤ" ){
		suit_d[hand2_num]++;
	}else if( hand2_suit == "ハート" ){
		suit_h[hand2_num]++;
	}else if( hand2_suit == "クラブ" ){
		suit_c[hand2_num]++;
	}else if( hand2_suit == "スペード" ){
		suit_s[hand2_num]++;
	}

	if( suit == "D" ){
		return suit_d;
	}else if( suit == "H" ){
		return suit_h;
	}else if( suit == "C" ){
		return suit_c;
	}else if( suit == "S" ){
		return suit_s;
	}
}

function checkCard( suit_d, suit_h, suit_c, suit_s ) {
	// スートごとの配列を用意
	// カードを1枚ずつ処理
	// 配列にその数字があれば1を返す
	// 配列にその数字がなければ配列にいれる
	// 最後まで回れば0を返す

	for( let i = 0; i < 14; i++ ){
		if( suit_d[i] >= 2 ){
			return 1;
		}
		if( suit_h[i] >= 2 ){
			return 1;
		}
		if( suit_c[i] >= 2 ){
			return 1;
		}
		if( suit_s[i] >= 2 ){
			return 1;
		}
	}

	return 0;
}

function checkYaku( suit_d, suit_h, suit_c, suit_s ) {
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/
	let RFFlag = checkRF( suit_d, suit_h, suit_c, suit_s );
	if( RFFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "ロイヤルフラッシュ";
		return 0;
	}

	let SFFlag = checkSF( suit_d, suit_h, suit_c, suit_s );
	if( SFFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "ストレートフラッシュ";
		return 0;
	}

	let FourFlag = checkFour( suit_d, suit_h, suit_c, suit_s );
	if( FourFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "フォーカード";
		return 0;
	}

	let FullFlag = checkFull( suit_d, suit_h, suit_c, suit_s );
	if( FullFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "フルハウス";
		return 0;
	}

	let FlushFlag = checkFlush( suit_d, suit_h, suit_c, suit_s );
	if( FlushFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "フラッシュ";
		return 0;
	}

	let StraightFlag = checkStraight( suit_d, suit_h, suit_c, suit_s );
	if( StraightFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "ストレート";
		return 0;
	}

	let ThreeFlag = checkThree( suit_d, suit_h, suit_c, suit_s );
	if( ThreeFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "スリーカード";
		return 0;
	}

	let TwopairFlag = checkTwopair( suit_d, suit_h, suit_c, suit_s );
	if( TwopairFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "ツーペア";
		return 0;
	}

	let OnepairFlag = checkPair( suit_d, suit_h, suit_c, suit_s );
	if( OnepairFlag == 1 ){
		document.getElementById("yakuDisp").textContent = "ワンペア";
		return 0;
	}

	document.getElementById("yakuDisp").textContent = "ハイカード";
	return 1;
}

function checkRF( suit_d, suit_h, suit_c, suit_s ){
	if( ( suit_d[1] == 1 ) && ( suit_d[10] == 1 ) && ( suit_d[11] == 1 ) && ( suit_d[12] == 1 ) && ( suit_d[13] == 1 ) ){
		return 1;
	}
	if( ( suit_h[1] == 1 ) && ( suit_h[10] == 1 ) && ( suit_h[11] == 1 ) && ( suit_h[12] == 1 ) && ( suit_h[13] == 1 ) ){
		return 1;
	}
	if( ( suit_c[1] == 1 ) && ( suit_c[10] == 1 ) && ( suit_c[11] == 1 ) && ( suit_c[12] == 1 ) && ( suit_c[13] == 1 ) ){
		return 1;
	}
	if( ( suit_s[1] == 1 ) && ( suit_s[10] == 1 ) && ( suit_s[11] == 1 ) && ( suit_s[12] == 1 ) && ( suit_s[13] == 1 ) ){
		return 1;
	}
		
	return 0;
}

function checkSF( suit_d, suit_h, suit_c, suit_s ){
	for( let i = 1; i < 10; i++ ){
		if( suit_d[i] + suit_d[i + 1] + suit_d[i + 2] + suit_d[i + 3] + suit_d[i + 4] == 5 ){
			return 1;
		}
		if( suit_h[i] + suit_h[i + 1] + suit_h[i + 2] + suit_h[i + 3] + suit_h[i + 4] == 5 ){
			return 1;
		}
		if( suit_c[i] + suit_c[i + 1] + suit_c[i + 2] + suit_c[i + 3] + suit_c[i + 4] == 5 ){
			return 1;
		}
		if( suit_s[i] + suit_s[i + 1] + suit_s[i + 2] + suit_s[i + 3] + suit_s[i + 4] == 5 ){
			return 1;
		}
	}
		
	return 0;
}

function checkFour( suit_d, suit_h, suit_c, suit_s ){
	for( let i = 1; i < 14; i++ ){
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 4 ){
			return 1;
		}
	}
		
	return 0;
}

function checkFull( suit_d, suit_h, suit_c, suit_s ){
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/
	let three = 0;
	let pair = 0;
	for( let i = 1; i < 14; i++ ){
		console.log(i);
		console.log(three);
		console.log(pair);
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 3 ){
			three++;
		}
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 2 ){
			pair++;
		}
	}
	if( ( three == 2 ) || ( ( three == 1 ) && ( pair > 0 ) ) ){
		return 1;
	}

	return 0;
}

function checkFlush( suit_d, suit_h, suit_c, suit_s ){
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/

	let cnt_d = 0;
	let cnt_h = 0;
	let cnt_c = 0;
	let cnt_s = 0;

	for( let i = 1; i < 14; i++ ){
		cnt_d += suit_d[i];
		cnt_h += suit_h[i];
		cnt_c += suit_c[i];
		cnt_s += suit_s[i];
	}
	if( ( cnt_d >= 5 ) || ( cnt_h >= 5 ) || ( cnt_c >= 5 ) || ( cnt_s >= 5 ) ){
		return 1;
	}

	return 0;
}

function checkStraight( suit_d, suit_h, suit_c, suit_s ){
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/

	for( let i = 1; i < 10; i++ ){
		if( ( suit_d[i] == 1 ) || ( suit_h[i] == 1 ) || ( suit_c[i] == 1 ) || ( suit_s[i] == 1 ) ){
			if( ( suit_d[i + 1] == 1 ) || ( suit_h[i + 1] == 1 ) || ( suit_c[i + 1] == 1 ) || ( suit_s[i + 1] == 1 ) ){
				if( ( suit_d[i + 2] == 1 ) || ( suit_h[i + 2] == 1 ) || ( suit_c[i + 2] == 1 ) || ( suit_s[i + 2] == 1 ) ){
					if( ( suit_d[i + 3] == 1 ) || ( suit_h[i + 3] == 1 ) || ( suit_c[i + 3] == 1 ) || ( suit_s[i + 3] == 1 ) ){
						if( ( suit_d[i + 4] == 1 ) || ( suit_h[i + 4] == 1 ) || ( suit_c[i + 4] == 1 ) || ( suit_s[i + 4] == 1 ) ){
							return 1;
						}
					}
				}
			}
		}
	}

	if( ( suit_d[1] == 1 ) || ( suit_h[1] == 1 ) || ( suit_c[1] == 1 ) || ( suit_s[1] == 1 ) ){
		if( ( suit_d[10] == 1 ) || ( suit_h[10] == 1 ) || ( suit_c[10] == 1 ) || ( suit_s[10] == 1 ) ){
			if( ( suit_d[11] == 1 ) || ( suit_h[11] == 1 ) || ( suit_c[11] == 1 ) || ( suit_s[11] == 1 ) ){
				if( ( suit_d[12] == 1 ) || ( suit_h[12] == 1 ) || ( suit_c[12] == 1 ) || ( suit_s[12] == 1 ) ){
					if( ( suit_d[13] == 1 ) || ( suit_h[13] == 1 ) || ( suit_c[13] == 1 ) || ( suit_s[13] == 1 ) ){
						return 1;
					}
				}
			}
		}
	}

	return 0;
}
	
function checkThree( suit_d, suit_h, suit_c, suit_s ){
	for( let i = 1; i < 14; i++ ){
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 3 ){
			return 1;
		}
	}
		
	return 0;
}

function checkTwopair( suit_d, suit_h, suit_c, suit_s ){
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/
	let cnt_pair = 0;
	for( let i = 1; i < 14; i++ ){
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 2 ){
			cnt_pair++;
		}
	}
	if( cnt_pair >= 2 ){
		return 1;
	}

	return 0;
}
	
function checkPair( suit_d, suit_h, suit_c, suit_s ){
/*
console.log(suit_d);
console.log(suit_h);
console.log(suit_c);
console.log(suit_s);
*/
	for( let i = 1; i < 14; i++ ){
		if( suit_d[i] + suit_h[i] + suit_c[i] + suit_s[i] == 2 ){
			return 1;
		}
	}

	return 0;
}


function closeWindow() {
	open('about:blank', '_self').close();    //一度再表示してからClose
}
