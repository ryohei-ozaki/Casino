function ruleOpen( target ) {
	if( target == "all" ){
		document.getElementById("ruleList").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "bj" ){
		document.getElementById("bjRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "baccarat" ){
//		document.getElementById("baccaratRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "hitOrStay" ){
		document.getElementById("hitOrStayRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
	}
}

function ruleClose( target ) {
	if( target == "all" ){
		document.getElementById("menuList").style.display ="block";

		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "bj" ){
		document.getElementById("ruleList").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "baccarat" ){
		document.getElementById("ruleList").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "hitOrStay" ){
		document.getElementById("ruleList").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}
}

function bjPlay() {
	window.open("../../BJ/html/BJ.html");
}

function calc100Play() {
	window.open("../../Calc100/html/Calc100.html");
}

function yakuHante1Play() {
	window.open("../../YakuHante1/html/YakuHante.html");
}

function yakuHante2Play() {
	window.open("../../YakuHante2/html/YakuHante.html");
}

function hitOrStayPlay() {
	window.open("../../HitOrStay/html/HitOrStay.html");
}

function howCalc() {
	window.open("../../HowCalc/html/HowCalc.html");
}