function rule_open() {
	document.getElementById("rule").style.display ="block";
}

function rule_close() {
	document.getElementById("rule").style.display ="none";
}

function BJ_play() {
	window.open("BJ.html");
}