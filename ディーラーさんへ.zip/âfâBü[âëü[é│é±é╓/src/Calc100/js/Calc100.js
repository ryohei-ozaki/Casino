let timer = 0;
let timerID;

function start_count() {
	//スタート
	timer = 0;	// 初期化
	timerID = setInterval("count_up()",1000); 
}

function stop_count() {
	//ストップ
	clearInterval(timerID);
}

function count_up() {
	timer++;
	document.getElementById("timer").value = count_format(timer);
}

function count_format(num) {
	var ts = num % 60;
	var tm = Math.floor(num / 60);
	var th = Math.floor(tm / 60);
	tm = tm % 60;
	//表示の整形
	if (ts < 10) ts = "0" + ts;
	if (tm < 10) tm = "0" + tm;
	if (th < 10) th = "0" + th;
	return th + ":" + tm + ":" + ts;
}

function start() {
	document.getElementById("start").disabled=true;
	document.getElementById("stop").disabled=false;
	document.getElementById("modeRadio").style.display ="none";
	document.getElementById("keta1").disabled=true;
	document.getElementById("keta2").disabled=true;
	document.getElementById("type").disabled=true;

	// 表の初期化
	document.getElementById("timer").value = '00:00:00';
	clearList();

	let mode;
	if( document.getElementById("modebasic").checked == true ){
		mode = 'basic';
	}else if( document.getElementById("modebj").checked == true ){
		mode = 'bj';
	}

	//通常モード
	if( mode == 'basic' ){
		let keta1 = document.getElementById("keta1").value;
		let keta2 = document.getElementById("keta2").value;
		let up_arr = [];
		let left_arr = [];

		if( keta1 == 'keta11' ){
			up_arr = make_hitoketa();
		}else if( keta1 == 'keta12' ){
			up_arr = make_futaketa();
		}

		if( keta2 == 'keta21' ){
			left_arr = make_hitoketa();
		}else if( keta2 == 'keta22' ){
			left_arr = make_futaketa();
		}

		let type;
		let disp_type;
		type = document.getElementById("type").value;
		if( type == 'tasu' ){
			disp_type = '+';
		}else if( type == 'hiku' ){
			disp_type = '-';
		}else if( type == 'kakeru' ){
			disp_type = '×';
		}

		let area = document.getElementById("calc100Table");
		area.rows[0].cells[0].innerText = disp_type;
		for( let i = 0; i < 10; i++ ){
			area.rows[0].cells[i + 1].innerText = up_arr[i];
			area.rows[i + 1].cells[0].innerText = left_arr[i];
		}
	}

	//bjモード
	if( mode == 'bj' ){
		let up_arr = [];
		let left_arr = [];

		up_arr = make_bj_up();
		left_arr = make_bj_left();

		let area = document.getElementById("calc100Table");
		area.rows[0].cells[0].innerText = '×';
		for( let i = 0; i < 10; i++ ){
			area.rows[0].cells[i + 1].innerText = up_arr[i];
			area.rows[i + 1].cells[0].innerText = left_arr[i];
		}
	}

	start_count();
}

function stop() {
	stop_count();

	document.getElementById("start").disabled=false;
	document.getElementById("stop").disabled=true;
	document.getElementById("modeRadio").style.display ="block";
	document.getElementById("keta1").disabled=false;
	document.getElementById("keta2").disabled=false;
	document.getElementById("type").disabled=false;

	// 答え合わせ
	checkAnswer();
}

function make_hitoketa() {
	let arr = [0,1,2,3,4,5,6,7,8,9];
	let a = arr.length;
	
	//シャッフルアルゴリズム
	while (a) {
		let j = Math.floor( Math.random() * a );
		let t = arr[--a];
		arr[a] = arr[j];
		arr[j] = t;
	}

	//シャッフルされた配列を返却する
	return arr;
}

// 二桁の数値からなる配列を作成
function make_futaketa() {
	let arr = [];
	for( let i = 10; i < 100; i++ ){
		arr.push(i);
	}
	let a = arr.length;
	
	//シャッフルアルゴリズム
	while (a) {
		let j = Math.floor( Math.random() * a );
		let t = arr[--a];
		arr[a] = arr[j];
		arr[j] = t;
	}

	//シャッフルされた配列の先頭10個を返却する
	let res = [];
	for( let i = 0; i < 10; i++ ){
		res.push(arr[i]);
	}
	return res;
}

function make_bj_up() {
	let arr = [0.5,1,1.5,2,3,4,6,10,12,25];
	let a = arr.length;
	
	//シャッフルアルゴリズム
	while (a) {
		let j = Math.floor( Math.random() * a );
		let t = arr[--a];
		arr[a] = arr[j];
		arr[j] = t;
	}

	//シャッフルされた配列を返却する
	return arr;
}

function make_bj_left() {
	let arr = [];
	for( let i = 5; i < 100; i += 5 ){
		arr.push(i);
	}
	let a = arr.length;
	
	//シャッフルアルゴリズム
	while (a) {
		let j = Math.floor( Math.random() * a );
		let t = arr[--a];
		arr[a] = arr[j];
		arr[j] = t;
	}

	//シャッフルされた配列の先頭10個を返却する
	let res = [];
	for( let i = 0; i < 10; i++ ){
		res.push(arr[i]);
	}
	return res;
}

// 表のクリア
function clearList() {
	let area = document.getElementById("calc100Table");
	for( let i = 0; i < 10; i++ ){
		for( let j = 0; j < 10; j++ ){
			area.rows[i + 1].cells[j + 1].getElementsByTagName("input")[0].value = '';
			area.rows[i + 1].cells[j + 1].getElementsByTagName("input")[0].style.backgroundColor = '#ffffff';
		}
	}
}

// 答え合わせ
function checkAnswer() {
	//mode取得
	let mode;
	if( document.getElementById("modebasic").checked == true ){
		mode = 'basic';
	}else if( document.getElementById("modebj").checked == true ){
		mode = 'bj';
	}

	let type;
	if( mode == 'basic' ){
		type = document.getElementById("type").value;
	}else if( mode == 'bj' ){
		type = 'kakeru';
	}
	let area = document.getElementById("calc100Table");
	let expectation_res;
	let diff_cnt = 0;

	for( let i = 0; i < 10; i++ ){
		for( let j = 0; j < 10; j++ ){
//			console.log(area.rows[0].cells[j + 1].getElementsByTagName("input")[0]);
//			let value1 = area.rows[0].cells[j + 1].getElementsByTagName("input")[0].value;
//			let value2 = area.rows[i + 1].cells[0].getElementsByTagName("input")[0].value;
			let value1 = parseFloat(area.rows[0].cells[j + 1].innerText);
			let value2 = parseFloat(area.rows[i + 1].cells[0].innerText);

			if( type == 'tasu' ){
				expectation_res = value1 + value2;
			}else if( type == 'hiku' ){
				expectation_res = Math.abs( value1 - value2 );
			}else if( type == 'kakeru' ){
				expectation_res = value1 * value2;
			}
			let ans = parseFloat(area.rows[i + 1].cells[j + 1].getElementsByTagName("input")[0].value);

			if( ans != expectation_res ){
				area.rows[i + 1].cells[j + 1].getElementsByTagName("input")[0].style.backgroundColor = '#FFFF66';
				diff_cnt++;
			}
		}
	}

	let right_cnt = 100 - diff_cnt;
	let time = document.getElementById("timer").value;
	let msg = "ただ今の記録\n正解数:" + right_cnt + "\n時間:" + time;
	alert( msg );
}

function onRadioButtonChange( mode ) {
	if( mode == 'basic' ){
		document.getElementById("basicModeConf").style.display ="block";
	}else if( mode == 'bj' ){
		document.getElementById("basicModeConf").style.display ="none";
	}
}

function closeWindow() {
	open('about:blank', '_self').close();    //一度再表示してからClose
}
