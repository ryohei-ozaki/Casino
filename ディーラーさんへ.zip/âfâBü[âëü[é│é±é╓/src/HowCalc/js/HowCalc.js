function calcOpen( target ) {
	let open_id;
	if( target == '1.5x' ){
		open_id = '1.5x';
	}else if( target == '6x' ){
		open_id = '6x';
	}else if( target == '12x' ){
		open_id = '12x';
	}

	document.getElementById("1.5x").style.display ="none";
	document.getElementById("6x").style.display ="none";
	document.getElementById("12x").style.display ="none";

	document.getElementById(open_id).style.display ="block";

/*
	if( target == "1.5x" ){
		document.getElementById("1.5x").style.display ="block";

		document.getElementById("6x").style.display ="none";

//		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
//		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "6x" ){
		document.getElementById("6x").style.display ="block";

		document.getElementById("1.5x").style.display ="none";

		//		document.getElementById("ruleList").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
//		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "baccarat" ){
//		document.getElementById("baccaratRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "hitOrStay" ){
		document.getElementById("hitOrStayRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
	}
*/

}

function calcClose( target ) {
	if( target == "1.5x" ){
		document.getElementById("1.5x").style.display ="none";
	}

	if( target == "6x" ){
		document.getElementById("6x").style.display ="none";
	}

	if( target == "12x" ){
		document.getElementById("12x").style.display ="none";
	}

	if( target == "baccarat" ){
//		document.getElementById("baccaratRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
		document.getElementById("hitOrStayRule").style.display ="none";
	}

	if( target == "hitOrStay" ){
		document.getElementById("hitOrStayRule").style.display ="block";

		document.getElementById("menuList").style.display ="none";
		document.getElementById("ruleList").style.display ="none";
		document.getElementById("bjRule").style.display ="none";
//		document.getElementById("baccaratRule").style.display ="none";
	}
}
