let cards;
let cardNum = 0;
let playerCards;
let dealerCards;
let over1000Flag = 0;
let waitFlag = 0;

function betIncrement( num ) {
	let myMoney = document.getElementById("myMoneyNum").value;
	let flag = checkMyMoney(parseFloat(myMoney) - num);
	if( flag == 0 ){
		return;
	}

	let bet = document.getElementById("mainBet").value;

	if( ( parseFloat( bet ) + num ) > 500 ){
		num = 500 - parseFloat( bet );
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) - num;
		document.getElementById("mainBet").value = parseFloat( bet ) + num;
	}else{
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) - num;
		document.getElementById("mainBet").value = parseFloat( bet ) + num;
	}
}

function betDecrement( num ) {
	let bet = document.getElementById("mainBet").value;
	if( ( parseFloat( bet ) - num ) < 0 ){
		document.getElementById("mainBet").value = 0;
		let myMoney = document.getElementById("myMoneyNum").value;
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) + parseFloat( bet );
	}else{
		document.getElementById("mainBet").value = parseFloat( bet ) - num;
		let myMoney = document.getElementById("myMoneyNum").value;
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) + num;
	}
}

function pareBetIncrement( num ) {
	let myMoney = document.getElementById("myMoneyNum").value;
	let flag = checkMyMoney( parseFloat( myMoney ) - num );
	if( flag == 0 ){
		return;
	}

	let bet = document.getElementById("pareBet").value;

	if( ( parseFloat( bet ) + num ) > 500 ){
		num = 500 - parseFloat( bet );
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) - num;
		document.getElementById("pareBet").value = parseFloat( bet ) + num;
	}else{
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) - num;
		document.getElementById("pareBet").value = parseFloat( bet ) + num;
	}
}

function pareBetDecrement( num ) {
	let bet = document.getElementById("pareBet").value;
	if( ( parseFloat( bet ) - num ) < 0 ){
		document.getElementById("pareBet").value = 0;
		let myMoney = document.getElementById("myMoneyNum").value;
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) + parseFloat( bet );
	}else{
		document.getElementById("pareBet").value = parseFloat( bet ) - num;
		let myMoney = document.getElementById("myMoneyNum").value;
		document.getElementById("myMoneyNum").value = parseFloat( myMoney ) + num;
	}
}

function checkMyMoney( value ) {
	if( value < 0 ){
		document.getElementById("dealer").textContent = "ディーラー：チップが不足しています。";
		return 0;
	}
	return 1;
}

function checkMainBet( value ) {
	if( value < 10 ){
		document.getElementById("dealer").textContent = "ディーラー：ミニマムベットは10です。";
		return 0;
	}

	if( value > 500 ){
		document.getElementById("dealer").textContent = "ディーラー：マックスベットは500です。";
		return 0;
	}
	return 1;
}

function checkPareBet( value ) {
	let mainBet = parseFloat( document.getElementById("mainBet").value );
	if( value > mainBet ){
		document.getElementById("dealer").textContent = "ディーラー：ペアベットの上限はメインベットまでです。";
		return 0;
	}
	return 1;
}

async function playGame() {

	let bet = parseFloat( document.getElementById("mainBet").value );
	let mainBetFlag = checkMainBet( bet );
	if( mainBetFlag == 0 ){
		return;
	}

	let parebet = parseFloat( document.getElementById("pareBet").value );
	let pareBetFlag = checkPareBet( parebet );
	if( pareBetFlag == 0 ){
		return;
	}

	noMoreBet();

	cards = shuffleCards();
	cardNum = 0;

	playerCards = [];
	dealerCards = [];

	playerCards[0] = getCard( cards, cardNum );
	cardNum++;

	dispCard( playerCards[0], 0, 'player' );

	dealerCards[0] = getCard( cards, cardNum );
	cardNum++;

	dispCard( dealerCards[0], 0, 'dealer' );

	playerCards[1] = getCard( cards, cardNum );
	cardNum++;

	dispCard( playerCards[1], 1, 'player' );

	dealerCards[1] = getCard( cards, cardNum );
	cardNum++;

	checkPare( playerCards );

	if( waitFlag != 0 ){
		await sleep( waitFlag );
		waitFlag = 0;
	}


	playerBJFlag = BJCheck( playerCards );
	dealerFaceCardAceFlag = dealerFaceCardAceCheck( dealerCards[0] );

	if( playerBJFlag == 1 ){
		compare();
		document.getElementById("actionArea").style.display ="none";
		let nextGameFlag = checkNextGame();
		if( nextGameFlag == 1 ){
			document.getElementById("next").style.display ="block";
		}
	}else{
		checkCanDouble();

		waitAction();
	}
}

function noMoreBet() {
	document.getElementById("dealer").textContent = "ディーラー：No more bet";

	let inputItem = document.getElementById("chips").getElementsByTagName("input");
	for( let i = 0; i < inputItem.length; i++ ){
		inputItem[i].disabled = true;
	}
/*
	document.getElementById("betinc100").disabled=true;
	document.getElementById("betinc25").disabled=true;
	document.getElementById("betinc10").disabled=true;
	document.getElementById("betinc5").disabled=true;
	document.getElementById("betinc1").disabled=true;
	document.getElementById("betdec1").disabled=true;
	document.getElementById("betdec5").disabled=true;
	document.getElementById("betdec10").disabled=true;
	document.getElementById("betdec25").disabled=true;
	document.getElementById("betdec100").disabled=true;
	document.getElementById("playGame").disabled=true;
*/
}

function shuffleCards() {
	var arr = [];
	let num; 
	for(var i=0; i < 312; i++){
		arr[i]=i;
	}

	for( let loop = 0; loop < 2; loop++ ){
		for(var j = 0; j < 312; j++) {
			rndNum = Math.floor( Math.random() * 1000 ) % 312;
			num = arr[j];
			arr[j] = arr[rndNum];
			arr[rndNum] = num;
		}
	}
	return arr;
}

function getCard( cards, num ) {
	return cards[num];
}

function dispCard( card, num, who ){
	let suit = getSuit( card );
	let number = getDispNumber( card );
	let dispCard = suit + "の" + number;

	let area;
	if( who == 'player' ){
		area = document.getElementById("playerAreaTable");
	}else if( who == 'dealer' ){
		area = document.getElementById("dealerAreaTable");
	}

	area.insertRow(num);
	area.rows[num].insertCell(0);
	area.rows[num].cells[0].innerText = ( num + 1 ) + "枚目：";
	area.rows[num].insertCell(1);
	area.rows[num].cells[1].innerText = dispCard;
}

function getSuit( card ){
	let num = card % 52;

	if( num < 13 ){
		return 'ハート';
	}

	if( num < 26 ){
		return 'ダイヤ';
	}

	if( num < 39 ){
		return 'クラブ';
	}

	return 'スペード';
}

function getDispNumber( card ){
	let num = card % 52;	
	num = num % 13;
	num++;
	if( num == 1 ){
		num = "A";
	}else if( num == 11 ){
		num = "J";
	}else if( num == 12 ){
		num = "Q";
	}else if( num == 13 ){
		num = "K";
	}

	return num;
}

function getNumber( card ){
	let num = card % 52;	
	num = num % 13;
	num++;

	return num;
}

async function checkPare( cards ) {
	let pareBet = parseFloat( document.getElementById("pareBet").value );
	if( pareBet == 0 ){
		return;
	}

	let firstNumper = getDispNumber( cards[0] );
	let secondNumper = getDispNumber( cards[1] );

	if( firstNumper != secondNumper ){
		document.getElementById("dealer").textContent = "ディーラー：ペアベットは残念。";
		await sleep( 1 );
		document.getElementById("pareBet").value = 0;
		return;
	}

	let firstSuit = getSuit( cards[0] );
	let secondSuit = getSuit( cards[1] );

	if( firstSuit == secondSuit ){
		document.getElementById("dealer").textContent = "ディーラー：ナイスパーフェクトペア！！！";
		await sleep( 2 );
		document.getElementById("pareBet").value = 0;
		let get = pareBet * 26;
		let myMoney = parseFloat( document.getElementById("myMoneyNum").value );
		document.getElementById("myMoneyNum").value = myMoney + get;
		return;
	}

	let firstRedFlag = 0;
	let secondRedFlag = 0;

	if( firstSuit == 'ハート' ){
		firstRedFlag = 1;
	}else if( firstSuit == 'ダイヤ' ){
		firstRedFlag = 1;
	}

	if( secondSuit == 'ハート' ){
		secondRedFlag = 1;
	}else if( secondSuit == 'ダイヤ' ){
		secondRedFlag = 1;
	}

	if( firstRedFlag == secondRedFlag ){
		document.getElementById("dealer").textContent = "ディーラー：ナイスカラーペア！！";
		await sleep( 2 );
		document.getElementById("pareBet").value = 0;
		let get = pareBet * 13;
		let myMoney = parseFloat( document.getElementById("myMoneyNum").value );
		document.getElementById("myMoneyNum").value = myMoney + get;
		return;
	}

	document.getElementById("dealer").textContent = "ディーラー：ナイスミックスペア！";
	document.getElementById("pareBet").value = 0;
	await sleep( 2 );
	let get = pareBet * 7;
	let myMoney = parseFloat( document.getElementById("myMoneyNum").value );
	document.getElementById("myMoneyNum").value = myMoney + get;
	return;
}

function BJCheck( cards ) {
	let aceFlag = checkAce( cards[0] );
	let tenFlag = checkTen( cards[0] );
	if( aceFlag == 0 ){
		aceFlag = checkAce( cards[1] );
	}
	if( tenFlag == 0 ){
		tenFlag = checkTen( cards[1] );
	}

	if( ( aceFlag == 1 ) && ( tenFlag == 1 ) ){
		return 1;
	}
	return 0;
}

function checkAce( card ) {
	let num = card % 52;
	num = num % 13;
	if( num == 0 ){
		return 1;
	}
	return 0;
}

function checkTen( card ) {
	let num = card % 52;
	num = num % 13;
	if( num >= 9 ){
		return 1;
	}
	return 0;
}

function dealerFaceCardAceCheck( card ) {
	let num = card % 52;
	num = num % 13;
	if( num == 0 ){
		return 1;
	}
	return 0;
}

function waitAction() {
	document.getElementById("actionArea").style.display ="block";
	document.getElementById("dealer").textContent = "ディーラー：アクションをしてください。";
}

function checkCanDouble() {
	let canDoubleFlag = 1;

	let myMoney = parseFloat(document.getElementById("myMoneyNum").value);
	let mainBet = parseFloat(document.getElementById("mainBet").value);

	if( myMoney < mainBet ) {
		canDoubleFlag = 0;
	}

	if( canDoubleFlag == 0 ) {
		document.getElementById("double").disabled=true;
	}
}

function hit() {
	let length = playerCards.length;
	playerCards[length] = getCard( cards, cardNum );
	cardNum++;

	dispCard( playerCards[length], length, 'player' );
	let burstFlag = checkBurst( playerCards );
	let flag21 = check21( playerCards );
	if( burstFlag == 1 ){
		document.getElementById("dealer").textContent = "ディーラー：残念、バーストです。";
		document.getElementById("actionArea").style.display ="none";
		let nextGameFlag = checkNextGame();
		if( nextGameFlag == 1 ){
			document.getElementById("next").style.display ="block";
		}
	}else if( flag21 == 1 ){
		document.getElementById("double").disabled=true;
		document.getElementById("hit").disabled=true;
		document.getElementById("dealer").textContent = "ディーラー：ナイス21!!";
	}else{
		document.getElementById("double").disabled=true;
		waitAction();
	}
}

function stay() {
	document.getElementById("actionArea").style.display ="none";
	let tokushuFlag = 0;
	tokushuFlag = checkTokushu();
	if( tokushuFlag == 0 ){
		compare();
	}

	let nextGameFlag = checkNextGame();
	if( nextGameFlag == 1 ){
		document.getElementById("next").style.display ="block";
	}
}

function double() {
	let mainBet = document.getElementById("mainBet").value;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat(myMoneyNum) - parseFloat(mainBet);
	document.getElementById("mainBet").value = parseFloat(mainBet) * 2;

	let length = playerCards.length;
	playerCards[length] = getCard( cards, cardNum );
	cardNum++;

	dispCard( playerCards[length], length, 'player' );
	let burstFlag = checkBurst( playerCards );

	if( burstFlag == 1 ){
		document.getElementById("dealer").textContent = "ディーラー：残念、バーストです。";
		document.getElementById("actionArea").style.display ="none";
		let nextGameFlag = checkNextGame();
		if( nextGameFlag == 1 ){
			document.getElementById("next").style.display ="block";
		}
	}else{
		document.getElementById("actionArea").style.display ="none";
		compare();
		let nextGameFlag = checkNextGame();
		if( nextGameFlag == 1 ){
			document.getElementById("next").style.display ="block";
		}
	}
}

function checkBurst( cards ) {
	let sum = 0;
	let length = cards.length;
	for( let cnt = 0; cnt < length; cnt++ ){
		let num = cards[cnt] % 52;
		num = num % 13;
		if( num >= 9 ){
			num = 9;
		}
		sum = sum + num + 1;
	}

	if( sum > 21 ){
		return 1;
	}else{
		return 0;
	}
}

function check21( cards ){
	let sum = 0;
	let length = cards.length;

	for( let cnt = 0; cnt < length; cnt++ ){
		let num = cards[cnt] % 52;
		num = num % 13;
		if( num >= 9 ){
			num = 9;
		}
		sum = sum + num + 1;
	}

	if( sum == 21 ){
		return 1;
	}else{
		return 0;
	}
}

function compare() {
	dispCard( dealerCards[1], 1, 'dealer' );

	playerBJFlag = BJCheck( playerCards );
	dealerBJFlag = BJCheck( dealerCards );

	if( playerBJFlag == 1 ){
		if( dealerBJFlag == 1 ){
			draw();
			return;
		}
		BJwin();
		return;
	}

	if( dealerBJFlag == 1 ){
		lose();
		return;
	}

	let over17Flag = checkOver17( dealerCards );
	while( over17Flag == 0 ){
		let length = dealerCards.length;
		dealerCards[length] = getCard( cards, cardNum );
		cardNum++;

		dispCard( dealerCards[length], length, 'dealer' );

		over17Flag = checkOver17( dealerCards );
	}

	let playerSum = getPlayerSum( playerCards );

	if( over17Flag > 21 ){
		win();
		return;
	}

	if( playerSum > over17Flag ){
		win();
		return;
	}

	if( playerSum < over17Flag ){
		lose();
		return;
	}

	if( playerSum == over17Flag ){
		draw();
		return;
	}
}

function BJwin() {
	let get = parseFloat( document.getElementById("mainBet").value );
	get = get * 2.5;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat(myMoneyNum) + get;
	document.getElementById("dealer").textContent = "ディーラー：BJであなたの勝ちです。";
	checkOver1000();
}

function win() {
	let get = parseFloat( document.getElementById("mainBet").value );
	get = get * 2;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat(myMoneyNum) + get;
	document.getElementById("dealer").textContent = "ディーラー：あなたの勝ちです。";
	checkOver1000();
}

function draw() {
	let get = parseFloat( document.getElementById("mainBet").value );
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat(myMoneyNum) + get;
	document.getElementById("dealer").textContent = "ディーラー：プッシュです。";
}

function lose() {
	document.getElementById("dealer").textContent = "ディーラー：あなたの負けです。";
}

function checkOver17( cards ) {
	let sum1 = 0;
	let sum2 = 0;
	let length = cards.length;
	let aceFlag = 0;
	for( let cnt = 0; cnt < length; cnt++ ){
		let num = cards[cnt] % 52;
		num = num % 13;
		if( num >= 9 ){
			num = 9;
		}
		sum1 = sum1 + num + 1;
		if( num == 0 ){
			aceFlag = 1;
		}
	}
	if( aceFlag == 1 ){
		sum2 = sum1 + 10;
	}

	if( sum1 >= 17 ){
		return sum1;
	}

	if( ( sum2 >= 17 ) && ( sum2 <= 21 ) ){
		return sum2;
	}
	
	return 0;
}

function getPlayerSum( cards ) {
	let sum1 = 0;
	let sum2 = 0;
	let length = cards.length;
	let aceFlag = 0;
	for( let cnt = 0; cnt < length; cnt++ ){
		let num = cards[cnt] % 52;
		num = num % 13;
		if( num >= 9 ){
			num = 9;
		}
		sum1 = sum1 + num + 1;
		if( num == 0 ){
			aceFlag = 1;
		}
	}
	if( aceFlag == 1 ){
		sum2 = sum1 + 10;
	}

	if( aceFlag == 1 ){
		if( sum2 <= 21 ){
			return sum2;
		}
	}

	return sum1;
}

function checkTokushu() {
	let under7Flag = 0;
	under7Flag = check7Under();
	if( under7Flag == 1 ){
		return 1;
	}

	let under6Flag = 0;
	under6Flag = check6Under();
	if( under6Flag == 1 ){
		return 1;
	}

	let flag777 = 0;
	flag777 = check777();
	if( flag777 == 1 ){
		return 1;
	}

	let flag678 = 0;
	flag678 = check678();
	if( flag678 == 1 ){
		return 1;
	}

	return 0;
}

function check7Under() {
	let length = playerCards.length;

	if( length >= 7 ){
		document.getElementById("dealer").textContent = "ディーラー：ナイス7アンダー!!";
		let get = parseFloat( document.getElementById("mainBet").value );
		get = get * 11;
		let myMoneyNum = document.getElementById("myMoneyNum").value;
		document.getElementById("myMoneyNum").value = parseFloat( myMoneyNum ) + get;
		document.getElementById("mainBet").value = 0;
		checkOver1000();

		return 1;
	}

	return 0;
}

function check6Under() {
	let length = playerCards.length;

	if( length < 6 ){
		return 0;
	}

	let text = "ディーラー：ナイス6アンダー!!";
	let bai = 5;
	let waitTime = 3;

	if( length == 6 ){
		let compareArray = [];
		for( let cnt = 0; cnt < 13; cnt++ ){
			compareArray[cnt] = 0;
		}
		for( let cnt = 0; cnt < length; cnt++ ){
			let num = getNumber( playerCards[cnt] ) - 1;
			compareArray[num] = 1;
		}

		let sum = compareArray[0] + compareArray[1] + compareArray[2] + compareArray[3] + compareArray[4] + compareArray[5];
		if( sum == 6 ){
			text = "ディーラー：ナイス6アンダーストレート!!!!!";
			bai = 101;
			waitTime = 5;
		}
	}

	document.getElementById("dealer").textContent = text;
	let get = parseFloat( document.getElementById("mainBet").value );
	get = get * bai;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat( myMoneyNum ) + get;
	document.getElementById("mainBet").value = 0;
	checkOver1000();

	return 1;
}

function check777() {
	let length = playerCards.length;
	if( length != 3 ){
		return 0;
	}

	let suit = [];
	let text = "ディーラー：ナイス777!!";
	let bai = 4;

	for( let i = 0; i < 3; i++ ){
		let num = playerCards[i];
		suit[i] = getSuit( num );
		num = num % 52;
		num = num % 13;
		if( num != 6 ){
			return 0;
		}
	}

	if( suit[0] == suit[1] ){
		if( suit[1] == suit[2] ){
			text = "ディーラー：ナイスフラッシュ777!!!!!";
			bai = 101;
		}
	}

	document.getElementById("dealer").textContent = text;
	let get = parseFloat( document.getElementById("mainBet").value );
	get = get * bai;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat( myMoneyNum ) + get;
	document.getElementById("mainBet").value = 0;
	checkOver1000();
	return 1;
}

function check678() {
	let length = playerCards.length;
	if( length != 3 ){
		return 0;
	}

	let exists6Flag = 0;
	let exists7Flag = 0;
	let exists8Flag = 0;

	let suit = [];
	let text = "ディーラー：ナイス678!!";
	let bai = 3;

	for( let i = 0; i < 3; i++ ){
		let num = playerCards[i];

		suit[i] = getSuit( num );

		num = num % 52;
		num = num % 13;
		if( num == 5 ){
			exists6Flag = 1;
		}
		if( num == 6 ){
			exists7Flag = 1;
		}
		if( num == 7 ){
			exists8Flag = 1;
		}
	}

	if( exists6Flag == 0 ){
		return 0;
	}
	if( exists7Flag == 0 ){
		return 0;
	}
	if( exists8Flag == 0 ){
		return 0;
	}

	if( suit[0] == suit[1] ){
		if( suit[1] == suit[2] ){
			text = "ディーラー：ナイスフラッシュ678!!!!!";
			bai = 101;
		}
	}

	document.getElementById("dealer").textContent = text;
	let get = parseFloat( document.getElementById("mainBet").value );
	get = get * bai;
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	document.getElementById("myMoneyNum").value = parseFloat( myMoneyNum ) + get;
	document.getElementById("mainBet").value = 0;
	checkOver1000();
	return 1;
}

function checkNextGame() {
	let myMoneyNum = document.getElementById("myMoneyNum").value;
	if( myMoneyNum < 10 ){
		document.getElementById("dealer").textContent = "ディーラー：Game Over(´・ω・`)";
		return 0;
	}else{
		return 1;
	}
}

function nextGame() {
	document.getElementById("next").style.display ="none";
	document.getElementById("double").disabled=false;
	document.getElementById("hit").disabled=false;

	let rows = document.getElementById("playerAreaTable").rows.length;
	for( let cnt = 0; cnt < rows; cnt++ ){
		document.getElementById("playerAreaTable").deleteRow(0);
	}

	rows = document.getElementById("dealerAreaTable").rows.length;
	for( let cnt = 0; cnt < rows; cnt++ ){
		document.getElementById("dealerAreaTable").deleteRow(0);
	}

	let inputItem = document.getElementById("chips").getElementsByTagName("input");
	for( let i = 0; i < inputItem.length; i++ ){
		inputItem[i].disabled = false;
	}
/*
	document.getElementById("betinc100").disabled=false;
	document.getElementById("betinc25").disabled=false;
	document.getElementById("betinc10").disabled=false;
	document.getElementById("betinc5").disabled=false;
	document.getElementById("betinc1").disabled=false;
	document.getElementById("betdec1").disabled=false;
	document.getElementById("betdec5").disabled=false;
	document.getElementById("betdec10").disabled=false;
	document.getElementById("betdec25").disabled=false;
	document.getElementById("betdec100").disabled=false;
	document.getElementById("playGame").disabled=false;
*/
	document.getElementById("mainBet").value = 0;

	document.getElementById("dealer").textContent = "ディーラー：Place your bet";
}

function checkOver1000(){
	let myMoneyNum = parseFloat( document.getElementById("myMoneyNum").value );
	if( ( myMoneyNum >= 1000 ) && ( over1000Flag == 0 ) ){
		alert("1,000点を超えました。おめでとうございます。プレイしていただきありがとうございました！パスワードは「graduation」です。");
		over1000Flag = 1;
	}
}

function sleep( sec ) {
	let msec = sec * 1000;
	waitFlag = sec;

	return new Promise(function(resolve) {

		setTimeout(function() {resolve()}, msec);

	})
}

function busyWait( waitSec ) {
	let waitMsec = waitSec * 1000;
	let startMsec = new Date();

	// 指定ミリ秒間だけループさせる（CPUは常にビジー状態）
	while (new Date() - startMsec < waitMsec);

	waitFlag = 0;
}